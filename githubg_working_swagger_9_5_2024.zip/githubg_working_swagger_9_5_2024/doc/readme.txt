Swagger API

http://localhost:8080/repository/operation/doc
http://localhost:8080/swagger-ui.html
